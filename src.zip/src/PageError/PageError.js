import React, { Component } from 'react';

class PageError extends Component {
  render() {
    return (
      <div className="page">
        <p>Página no encontrada</p>
      </div>
    );
  }
}

export default PageError;