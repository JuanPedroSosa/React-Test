import React from "react";

export const MainBanner = props => (
  <h4 className="bg-primary text-white text-left p-4">
    {props.userName}
  </h4>
);