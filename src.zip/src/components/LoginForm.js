import React, {Component} from 'react';

class LoginForm extends Component {
	constructor() {
		super();
		this.state = {
			username: '',
			password: '',
		}
		// React pierde el scope this, entonces con bind le decimos a la
		// clase que pertenece
		this.handleInput = this.handleInput.bind(this);
		this.handleSubmit = this.handleSubmit.bind(this);
	}

	handleInput (e) {
		console.log("event: " + e.target.name, e.target.value);
		const {name, value} = e.target;
		this.setState({
			[name] : value
		})
	}

	async handleSubmit(e) {
		// evita que se refresque la pantalla
		e.preventDefault();
		//this.setState({username:'hola'})
		console.log(`login submit: ${this.state.username}`);
		this.props.onAddUsers(this.state);
		const token = await loginUser({
      username: this.state.username,
      password: this.state.password
		});
		console.log(`login token: ${JSON.stringify(token)}`);
		this.props.setToken(token.token);
		console.log("fin login");
	}

	render() {
		return (
			<div className="card">
				<form className="card-body" onSubmit={this.handleSubmit}>
					<div className="form-group">
						<input
						type="text"
						name="username"
						onChange= {this.handleInput}//{(event, newValue) => this.setState({username:newValue})}
						className="form-control"
						placeholder="correo / número de celular">
						</input>
					</div>
					<div className="form-group">
						<input
						type="password"
						name="password"
						onChange= {this.handleInput}//{(event, newValue) => this.setState({password:newValue})}
						className="form-control"
						placeholder="clave">
						</input>
					</div>
					<button	type="submit" className="btn btn-block btn-primary">
						Ingresar
					</button>
				</form>
			</div>

		)
	}
}

async function loginUser(credentials) {
	return fetch('http://localhost:8080/login', {
		method: 'POST',
		headers: {
			'Content-Type': 'application/json'
		},
		body: JSON.stringify(credentials)
	}).then(data => data.json())
}

export default LoginForm;